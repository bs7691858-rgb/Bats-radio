BATS RADIO
رفع هذه الملفات إلى GitHub ثم افتح Actions وشغل Build Bats Radio APK.
بعد نجاح البناء افتح Artifacts وحمل bats-radio-apk.zip ثم فك الضغط للحصول على app-release.apk.
روابط الصوت الحالية تجريبية وستحتاج لاحقاً إلى مصادر بث حقيقية.
