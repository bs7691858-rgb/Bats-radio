import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const BatsRadioApp());

class BatsRadioApp extends StatelessWidget {
  const BatsRadioApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Bats Radio',
    theme: ThemeData.dark().copyWith(
      scaffoldBackgroundColor: Colors.black,
      colorScheme: ColorScheme.fromSeed(
        seedColor: Colors.amber, brightness: Brightness.dark)),
    home: const RadioHomePage(),
  );
}

class RadioHomePage extends StatefulWidget {
  const RadioHomePage({super.key});
  @override State<RadioHomePage> createState() => _RadioHomePageState();
}

class _RadioHomePageState extends State<RadioHomePage> {
  final AudioPlayer player = AudioPlayer();
  String selected = 'الكل';
  bool playing = false;

  final streams = const {
    'الذهب': 'https://example.com/gold.mp3',
    'الفوركس': 'https://example.com/forex.mp3',
    'المؤشرات': 'https://example.com/indices.mp3',
    'الكل': 'https://example.com/all.mp3',
  };

  Future<void> toggleRadio() async {
    if (playing) {
      await player.stop();
      setState(() => playing = false);
    } else {
      await player.play(UrlSource(streams[selected]!));
      setState(() => playing = true);
    }
  }

  Future<void> choose(String value) async {
    if (playing) await player.stop();
    setState(() { selected = value; playing = false; });
  }

  @override void dispose() { player.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(centerTitle: true, title: const Text('🦇 Bats Radio')),
    body: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(children: [
        const SizedBox(height: 24),
        const Text('إذاعة الأخبار الاقتصادية والتداول',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center),
        const SizedBox(height: 8),
        const Text('أهم أخبار السوق بصوت إذاعي',
          style: TextStyle(color: Colors.grey)),
        const SizedBox(height: 30),
        Wrap(
          alignment: WrapAlignment.center, spacing: 8, runSpacing: 8,
          children: streams.keys.map((item) => ChoiceChip(
            label: Text(item),
            selected: selected == item,
            onSelected: (_) => choose(item),
          )).toList()),
        const Spacer(),
        Container(
          width: 170, height: 170,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.amber, width: 2)),
          child: Icon(playing ? Icons.pause : Icons.mic,
            size: 78, color: Colors.amber)),
        const SizedBox(height: 22),
        Text(playing ? 'جاري البث: $selected' : 'الراديو متوقف',
          style: const TextStyle(fontSize: 18)),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: toggleRadio,
          icon: Icon(playing ? Icons.stop : Icons.play_arrow),
          label: Text(playing ? 'إيقاف البث' : 'استمع الآن')),
        const Spacer(),
        const Text('Bats Radio • أخبار التداول بالعربية',
          style: TextStyle(color: Colors.grey)),
      ]),
    ),
  );
}
