BATS RADIO - Android

هذا مشروع Flutter أولي لتطبيق Bats Radio.

ما فيه حالياً:
- الذهب
- الفوركس
- المؤشرات
- الكل
- زر تشغيل/إيقاف الراديو
- واجهة عربية داكنة

مهم:
روابط الصوت الموجودة في lib/main.dart تجريبية (example.com).
خاصك من بعد تبدلها بروابط بث صوتي حقيقية.

لبناء APK على الكمبيوتر:
1) ثبت Flutter و Android Studio.
2) افتح Terminal داخل مجلد المشروع.
3) نفذ:
   flutter pub get
   flutter build apk --release

الـAPK غادي تلقاه غالباً في:
build/app/outputs/flutter-apk/app-release.apk
