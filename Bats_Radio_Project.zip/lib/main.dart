import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

void main() => runApp(const BatsRadioApp());

class BatsRadioApp extends StatelessWidget {
  const BatsRadioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Bats Radio',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
        colorScheme: ColorScheme.fromSeed(
          seedColor: Colors.amber,
          brightness: Brightness.dark,
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final player = AudioPlayer();
  String selected = 'الكل';
  bool playing = false;

  // بدّل هذه الروابط لاحقاً بروابط البث الحقيقية.
  final streams = const {
    'الذهب': 'https://example.com/gold.mp3',
    'الفوركس': 'https://example.com/forex.mp3',
    'المؤشرات': 'https://example.com/indices.mp3',
    'الكل': 'https://example.com/all.mp3',
  };

  Future<void> toggleRadio() async {
    if (playing) {
      await player.stop();
      setState(() => playing = false);
      return;
    }
    final url = streams[selected]!;
    await player.play(UrlSource(url));
    setState(() => playing = true);
  }

  Future<void> selectCategory(String category) async {
    if (playing) await player.stop();
    setState(() {
      selected = category;
      playing = false;
    });
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text('🦇 Bats Radio'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const SizedBox(height: 20),
            const Text(
              'إذاعة الأخبار الاقتصادية والتداول',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'أخبار السوق المؤثرة بصوت إذاعي',
              style: TextStyle(color: Colors.grey.shade400),
            ),
            const SizedBox(height: 35),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: streams.keys.map((category) {
                final active = selected == category;
                return ChoiceChip(
                  label: Text(category),
                  selected: active,
                  onSelected: (_) => selectCategory(category),
                );
              }).toList(),
            ),
            const Spacer(),
            Container(
              width: 180,
              height: 180,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.amber, width: 2),
              ),
              child: Icon(
                playing ? Icons.pause : Icons.mic,
                size: 80,
                color: Colors.amber,
              ),
            ),
            const SizedBox(height: 25),
            Text(
              playing ? 'جاري البث: $selected' : 'الراديو متوقف',
              style: const TextStyle(fontSize: 18),
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: toggleRadio,
              icon: Icon(playing ? Icons.stop : Icons.play_arrow),
              label: Text(playing ? 'إيقاف البث' : 'استمع الآن'),
            ),
            const Spacer(),
            Text(
              'Bats Radio • أخبار التداول بالعربية',
              style: TextStyle(color: Colors.grey.shade600),
            ),
          ],
        ),
      ),
    );
  }
}
